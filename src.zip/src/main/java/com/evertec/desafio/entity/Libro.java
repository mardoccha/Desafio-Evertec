package com.evertec.desafio.entity;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "libro")
public class Libro {

    
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_libro", unique = true, nullable = false)
	private Integer idLibro;

    @Column(name = "titulo")
    private String titulo;

    @Column(name = "autor")
    private String autor;

    @Column(name = "year")
    private String year;

    @Column(name = "url_img")
    private String urlImg;

    @Column(name = "valor")
    private Integer valor;
    

      public Integer getIdLibro() {
        return idLibro;
    }


    public void setIdLibro(Integer idLibro) {
        this.idLibro = idLibro;
    }


    public String getTitulo() {
        return titulo;
    }


    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }


    public String getAutor() {
        return autor;
    }


    public void setAutor(String autor) {
        this.autor = autor;
    }


    public String getYear() {
        return year;
    }


    public void setYear(String year) {
        this.year = year;
    }


    public String getUrlImg() {
        return urlImg;
    }


    public void setUrlImg(String urlImg) {
        this.urlImg = urlImg;
    }


    public Integer getValor() {
        return valor;
    }


    public void setValor(Integer valor) {
        this.valor = valor;
    }


    public Libro() {
    }


    @Override
    public String toString() {
        
        try{

            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(this);

        }catch (Exception e) {
            e.printStackTrace();
        }

        return null;

    }
}
