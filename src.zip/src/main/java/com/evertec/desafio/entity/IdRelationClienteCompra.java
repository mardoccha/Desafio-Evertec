package com.evertec.desafio.entity;

import java.io.Serializable;


public class IdRelationClienteCompra  implements Serializable {


    
  private Integer idCliente; 
  private Integer idCompra;

  

public Integer getIdCompra() {
    return idCompra;
}
public void setIdCompra(Integer idCompra) {
    this.idCompra = idCompra;
}
public Integer getIdCliente() {
    return idCliente;
}
public void setIdCliente(Integer idCliente) {
    this.idCliente = idCliente;
}
   
     
}
