package com.evertec.desafio.entity;

import java.io.Serializable;


public class IdRelationLibroCompra  implements Serializable {


    
  private Integer idLibro; 
  private Integer idCompra;

  
public Integer getIdLibro() {
    return idLibro;
}
public void setIdLibro(Integer idLibro) {
    this.idLibro = idLibro;
}
public Integer getIdCompra() {
    return idCompra;
}
public void setIdCompra(Integer idCompra) {
    this.idCompra = idCompra;
}
   
     
}
