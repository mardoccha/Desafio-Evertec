package com.evertec.desafio.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.evertec.desafio.dto.TransactionDTO;

import jakarta.persistence.Column;
import jakarta.persistence.ColumnResult;
import jakarta.persistence.ConstructorResult;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedNativeQuery;
import jakarta.persistence.SqlResultSetMapping;
import jakarta.persistence.Table;


@Entity
@Table(name = "compra")
@NamedNativeQuery(
    name = "find_compra_dto",
    query = """
        SELECT 
             compra.id_compra as idTransaction, 
             compra.valor_total as valorTotal, 
             compra.fecha as fechaRealization, 
             cliente_has_compra.id_cliente as idCliente
             FROM bd_evertec.compra inner join cliente_has_compra on cliente_has_compra.id_compra=compra.id_compra
             
    """,
    resultSetMapping = "findTransactionDTO"
)
@NamedNativeQuery(
    name = "find_compra_cliente_dto",
    query = """
        SELECT 
             compra.id_compra as idTransaction, 
             compra.valor_total as valorTotal, 
             compra.fecha as fechaRealization, 
             cliente_has_compra.id_cliente as idCliente
             FROM bd_evertec.compra inner join cliente_has_compra on cliente_has_compra.id_compra=compra.id_compra
             where compra.id_compra= ?1 or cliente_has_compra.id_cliente= ?2
    """,
    resultSetMapping = "findTransactionDTO"
)
@SqlResultSetMapping(
    name = "findTransactionDTO",
    classes = @ConstructorResult(
        targetClass = TransactionDTO.class,
        columns = {
            @ColumnResult(name = "idTransaction", type = Integer.class),
            @ColumnResult(name = "idCliente", type = Integer.class),
            @ColumnResult(name = "valorTotal", type = Integer.class),
            @ColumnResult(name = "fechaRealization",type = LocalDateTime.class)
        }
    )
)
public class Compra {


    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_compra", unique = true, nullable = false)
    private Integer idCompra;

    @Column(name = "valor_total")
    private Integer valorTotal; 


    @Column(name = "fecha")
    private LocalDateTime fecha;


    public Integer getIdCompra() {
        return idCompra;
    }


    public void setIdCompra(Integer idCompra) {
        this.idCompra = idCompra;
    }


    public Integer getValorTotal() {
        return valorTotal;
    }


    public void setValorTotal(Integer valorTotal) {
        this.valorTotal = valorTotal;
    }


    public LocalDateTime getFecha() {
        return fecha;
    }


    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }


    public Compra(Integer idCompra, Integer valorTotal, LocalDateTime fecha) {
        this.idCompra = idCompra;
        this.valorTotal = valorTotal;
        this.fecha = fecha;
    }


    public Compra() {
    }     


    
    
}
