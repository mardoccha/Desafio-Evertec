package com.evertec.desafio.entity;

import java.io.Serializable;


import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "libro_has_compra")
@IdClass(IdRelationLibroCompra.class)
public class LibroHasTransaction  implements Serializable{


  @Id  
  @Column(name = "id_libro",  nullable = false,columnDefinition = "UNSIGNED")  
  private Integer idLibro;

  @Id
  @Column(name = "id_compra", nullable = false,columnDefinition = "UNSIGNED")  
  private Integer idCompra;


  @Column(name = "cantidad", nullable = false)
  private Integer cantidad;



public Integer getIdLibro() {
    return idLibro;
}


public void setIdLibro(Integer idLibro) {
    this.idLibro = idLibro;
}


public Integer getIdCompra() {
    return idCompra;
}


public void setIdCompra(Integer idCompra) {
    this.idCompra = idCompra;
}


public Integer getCantidad() {
    return cantidad;
}


public void setCantidad(Integer cantidad) {
    this.cantidad = cantidad;
}


public LibroHasTransaction(Integer idLibro, Integer idCompra, Integer cantidad) {
    this.idLibro = idLibro;
    this.idCompra = idCompra;
    this.cantidad = cantidad;
}


public LibroHasTransaction() {
}

     @Override
    public String toString() {
        
        try{

            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(this);

        }catch (Exception e) {
            e.printStackTrace();
        }

        return null;

    }

  
}
