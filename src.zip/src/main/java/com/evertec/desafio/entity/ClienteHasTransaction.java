package com.evertec.desafio.entity;
import java.io.Serializable;


import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "cliente_has_compra")
@IdClass(IdRelationClienteCompra.class)
public class ClienteHasTransaction  implements Serializable{


  @Id  
  @Column(name = "id_cliente",  nullable = false,columnDefinition = "UNSIGNED")  
  private Integer idCliente;

  @Id
  @Column(name = "id_compra", nullable = false,columnDefinition = "UNSIGNED")  
  private Integer idCompra;


public Integer getIdCliente() {
    return idCliente;
}



public void setIdCliente(Integer idCliente) {
    this.idCliente = idCliente;
}

public Integer getIdCompra() {
    return idCompra;
}

public void setIdCompra(Integer idCompra) {
    this.idCompra = idCompra;
}



public ClienteHasTransaction(Integer idCliente, Integer idCompra) {
    this.idCliente = idCliente;
    this.idCompra = idCompra;
}

public ClienteHasTransaction() {
}

     @Override
    public String toString() {
        
        try{

            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(this);

        }catch (Exception e) {
            e.printStackTrace();
        }

        return null;

    }

  
}
