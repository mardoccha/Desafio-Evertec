package com.evertec.desafio.excepciones;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.modelmapper.spi.ErrorMessage;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.ErrorResponseException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import com.evertec.desafio.dto.ErrorDetalles;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseBody
	@ResponseStatus
	public ResponseEntity<ErrorDetalles> manejarResourceNotFoundException(ResourceNotFoundException exception,
			WebRequest webRequest) {
		ErrorDetalles errorDetalles = new ErrorDetalles(new Date(), exception.getMessage(),
				webRequest.getDescription(false));
		return new ResponseEntity<>(errorDetalles, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(ApiException.class)
	@ResponseBody
	@ResponseStatus
	public ResponseEntity<ErrorDetalles> manejarApiException(ApiException exception, WebRequest webRequest) {
		ErrorDetalles errorDetalles = new ErrorDetalles(new Date(), exception.getMessage(),
				webRequest.getDescription(false));
		return new ResponseEntity<>(errorDetalles, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	@ResponseBody
	@ResponseStatus
	public ResponseEntity<ErrorDetalles> manejarGlobalException(Exception exception, WebRequest webRequest) {
		if(exception.getMessage()!=null){
			ErrorDetalles errorDetalles = new ErrorDetalles(new Date(),
				exception.getMessage().contains("Bad credentials") ? "Password incorrect"
						: exception.getMessage(),
				webRequest.getDescription(false));
		return new ResponseEntity<>(errorDetalles, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		ErrorDetalles errorDetalles = new ErrorDetalles(new Date(),"Null pointer exception",
				webRequest.getDescription(false));
		return new ResponseEntity<>(errorDetalles, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}

	@Override
	@ResponseStatus
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {

		Map<String, String> errores = new HashMap<>();

		ex.getBindingResult().getAllErrors().forEach((error) -> {
			String nombreCampo = ((FieldError) error).getField();
			String mensaje = error.getDefaultMessage();

			errores.put(nombreCampo, mensaje);
		});

		return new ResponseEntity<>(errores, HttpStatus.BAD_REQUEST);
	}

	@Override
	@ResponseStatus
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		ErrorDetalles errorDetalles = new ErrorDetalles(new Date(), ex.getMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorDetalles, HttpStatus.METHOD_NOT_ALLOWED);
	}

	@Override
	@ResponseStatus
	protected ResponseEntity<Object> handleNoResourceFoundException(NoResourceFoundException ex, HttpHeaders headers,
			HttpStatusCode status, WebRequest request) {
		ErrorDetalles errorDetalles = new ErrorDetalles(new Date(),
				"No existe ese path en el servidor : " + ex.getResourcePath(), request.getDescription(false));
		return new ResponseEntity<>(errorDetalles, HttpStatus.NOT_FOUND);
	}

	@Override
	@ResponseStatus
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {

		Map<String, Object> errorDetails = new HashMap<>();
		if (ex.getMostSpecificCause().getMessage().contains("entity.Cliente")) {

			errorDetails.put("rut", "requerido");
			errorDetails.put("nombre", "requerido");
			errorDetails.put("apellido", "requerido");

			ErrorDetalles errorDetalles = new ErrorDetalles(new Date(), ex.getMessage().split(":")[0], errorDetails);
			return new ResponseEntity<>(errorDetalles, HttpStatus.BAD_REQUEST);
		}
		if (ex.getMostSpecificCause().getMessage().contains("LoginDTO")) {

			errorDetails.put("usernameOrEmail", "requerido");
			errorDetails.put("password", "requerido");
			ErrorDetalles errorDetalles = new ErrorDetalles(new Date(), ex.getMessage().split(":")[0], errorDetails);
			return new ResponseEntity<>(errorDetalles, HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

	}

}
