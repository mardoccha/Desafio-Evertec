package com.evertec.desafio.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.evertec.desafio.entity.LibroHasTransaction;


   @Repository
    public interface LibroHasTransactionRepository extends JpaRepository<LibroHasTransaction, Integer>{

    @Query(value ="SELECT * from libro_has_compra where libro_has_compra.id_compra= ?1" 
   , nativeQuery = true)
    List<LibroHasTransaction> getLibrosByIdCompra(Integer idCompra);
    
}
