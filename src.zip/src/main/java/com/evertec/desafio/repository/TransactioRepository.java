package com.evertec.desafio.repository;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.evertec.desafio.dto.TransactionDTO;
import com.evertec.desafio.entity.Compra;


@Repository
public interface TransactioRepository extends JpaRepository<Compra, Integer>{

 //new com.evertec.desafio.dto.TransactionDTO(

    @Query(name ="find_compra_dto" 
   , nativeQuery = true)
    List<TransactionDTO> getAlltransaction();

 
    @Query(name ="find_compra_cliente_dto" 
   , nativeQuery = true)
    List<TransactionDTO> getClientTransaction(Integer idCompra, Integer idCliente);

    

}
