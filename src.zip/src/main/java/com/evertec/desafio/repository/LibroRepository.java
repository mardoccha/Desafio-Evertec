package com.evertec.desafio.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.evertec.desafio.entity.Libro;

@Repository
public interface LibroRepository extends JpaRepository<Libro, Integer>{
    
}
