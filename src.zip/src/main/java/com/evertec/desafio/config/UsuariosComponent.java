package com.evertec.desafio.config;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.evertec.desafio.dto.Role;
import com.evertec.desafio.dto.Usuario;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import jakarta.annotation.PostConstruct;

@Component
public class UsuariosComponent{

    @Autowired
    private PasswordEncoder passwordEncoder;

    String secretKey = "]R_S2LUutLbSaVt*dGqQRhu";
    List<Usuario> users = new ArrayList<>();

    @PostConstruct
    protected void inicializarUsuarios(){

        users.add(new Usuario(
            "DEVEVERTEC",
            passwordEncoder.encode("123456"),
            Role.DEV,
            "",    
            0
        ));

        users.add(new Usuario(
            "Testuser",
            passwordEncoder.encode("123456"),
            Role.TEST,
            "",
            1
            
        ));
        users.add(new Usuario(
            "PrivateUser",
            passwordEncoder.encode("123456"),
            Role.PRIVATE,
            "",
            2
            
        ));
    

    }

    private String getJWTToken(Usuario user) {
		
		List<GrantedAuthority> grantedAuthorities = AuthorityUtils.commaSeparatedStringToAuthorityList(user.getRole().toString());
		
		String token = Jwts
				.builder()
				.setSubject(user.getUser())
				.claim("authorities",
						grantedAuthorities.stream()
								.map(GrantedAuthority::getAuthority)
								.collect(Collectors.toList()))
                .claim("idUsuario",user.getIdUsuario())
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.signWith(SignatureAlgorithm.HS512,
						secretKey.getBytes()).compact();
						
                        System.out.println(token);
		return "Bearer " + token ;
	}

    public List<Usuario> getListaUsuarios(){
        return this.users;
    }
     
     public Usuario findByUsernameOrEmail(String username){

        for (Usuario user : users) {
           if (user.getUser().equals(username)) {
             return user;
           } 
        }
        return null;
    }

    
}