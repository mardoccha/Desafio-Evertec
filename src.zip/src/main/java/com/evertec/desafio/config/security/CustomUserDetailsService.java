package com.evertec.desafio.config.security;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.evertec.desafio.config.UsuariosComponent;
import com.evertec.desafio.dto.Usuario;

@Service
public class CustomUserDetailsService implements UserDetailsService{

	@Autowired
	private UsuariosComponent usuarios;
	
	@Override
	public UserDetails loadUserByUsername(String usernameOrEmail) throws UsernameNotFoundException {
		Usuario usuario = usuarios.findByUsernameOrEmail(usernameOrEmail);
		
		if (usuario == null)  throw new UsernameNotFoundException("Usuario no encontrado con ese username o email : " + usernameOrEmail);

			
		  List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

            authorities.add(new SimpleGrantedAuthority(usuario.getRole().toString()));

		return new User(usuario.getUser(), usuario.getPwd(), authorities);
	}

	
}
