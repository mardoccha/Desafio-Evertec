package com.evertec.desafio.dto;

import java.util.Date;

public class ErrorDetalles {

	private Date fecha;
	private String mensaje;
	private Object detalles;

	public ErrorDetalles(Date fecha, String mensaje, Object detalles) {
		super();
		this.fecha = fecha;
		this.mensaje = mensaje;
		this.detalles = detalles;
	}

	public Date getMarcaDeTiempo() {
		return fecha;
	}

	public void setMarcaDeTiempo(Date marcaDeTiempo) {
		this.fecha = marcaDeTiempo;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public Object getDetalles() {
		return detalles;
	}

	public void setDetalles(String detalles) {
		this.detalles = detalles;
	}

}
