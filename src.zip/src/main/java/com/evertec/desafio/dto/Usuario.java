package  com.evertec.desafio.dto;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;

public class Usuario {

	private String user;
	private String pwd;
	private Role role;
	private String token;
	private Integer idUsuario;


	public String getUser() {
		return this.user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPwd() {
		return this.pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public Role getRole() {
		return this.role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getToken() {
		return this.token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	

	public Usuario(String user, String pwd, Role role, String token, Integer idUsuario) {
		this.user = user;
		this.pwd = pwd;
		this.role = role;
		this.token = token;
		this.idUsuario = idUsuario;
	}

	


}
