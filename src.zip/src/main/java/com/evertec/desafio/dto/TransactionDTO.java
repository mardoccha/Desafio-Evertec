package com.evertec.desafio.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.evertec.desafio.entity.LibroHasTransaction;


public class TransactionDTO {

  private Integer idTransaction;
  private Integer  valorTotal;
  private Integer  cantidadLibro;
  private Integer  idCliente;
  private LocalDateTime fechaRealization;
  private List<LibroHasTransaction> listaLibro;



public Integer getIdCliente() {
    return idCliente;
}
public void setIdCliente(Integer idCliente) {
    this.idCliente = idCliente;
}
public void setListaLibro(List<LibroHasTransaction> listaLibro) {
    this.listaLibro = listaLibro;
}
public Integer getIdTransaction() {
    return idTransaction;
}
public void setIdTransaction(Integer idTransaction) {
    this.idTransaction = idTransaction;
}
public Integer getValorTotal() {
    return valorTotal;
}
public void setValorTotal(Integer valorTotal) {
    this.valorTotal = valorTotal;
}
public LocalDateTime getFechaRealization() {
    return fechaRealization;
}
public void setFechaRealization(LocalDateTime fechaRealization) {
    this.fechaRealization = fechaRealization;
}
public List<LibroHasTransaction> getListaLibro() {
    return listaLibro;
}
public TransactionDTO() {
}
public void setLista(List<LibroHasTransaction> listaLibro) {
    this.listaLibro = listaLibro;
}
public TransactionDTO(Integer idTransaction, Integer valorTotal, Integer idCliente, LocalDateTime fechaRealization,
        List<LibroHasTransaction> listaLibro) {
    this.idTransaction = idTransaction;
    this.valorTotal = valorTotal;
    this.idCliente = idCliente;
    this.fechaRealization = fechaRealization;
    this.listaLibro = listaLibro;
}
public Integer getCantidadLibro() {
    return cantidadLibro;
}
public void setCantidadLibro(Integer cantidadLibro) {
    this.cantidadLibro = cantidadLibro;
}

 
  
    
}
