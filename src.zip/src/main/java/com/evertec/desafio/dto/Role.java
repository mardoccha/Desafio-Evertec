package   com.evertec.desafio.dto;

public enum Role {

	TEST, PRIVATE, DEV;
	
}
