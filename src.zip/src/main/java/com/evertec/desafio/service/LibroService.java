package com.evertec.desafio.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evertec.desafio.entity.Libro;
import com.evertec.desafio.repository.LibroRepository;

@Service
public class LibroService {

    @Autowired
    LibroRepository libroRepository;


    public Libro ifBookExist(Integer idLibro) {
        try {
            
            return  libroRepository.getReferenceById(idLibro);

        } catch (Exception e) {
           return null;
        }

      
    }
    
    
}
