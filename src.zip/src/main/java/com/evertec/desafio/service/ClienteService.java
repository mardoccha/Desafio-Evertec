package com.evertec.desafio.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evertec.desafio.entity.Cliente;
import com.evertec.desafio.repository.ClienteRepositoty;

@Service
public class ClienteService {

    @Autowired
    ClienteRepositoty clienteRepositoty;


    public Cliente addCliente(Cliente cliente) {
        try {
            
            clienteRepositoty.save(cliente);

            return cliente;

        } catch (Exception e) {
           return null;
        }

      
    }
    

    public List<Cliente> getAllCliente() {

       return clienteRepositoty.findAll();

    }
}
