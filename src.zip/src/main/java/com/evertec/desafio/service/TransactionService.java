package com.evertec.desafio.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evertec.desafio.dto.TransactionDTO;
import com.evertec.desafio.entity.ClienteHasTransaction;
import com.evertec.desafio.entity.Compra;
import com.evertec.desafio.entity.LibroHasTransaction;
import com.evertec.desafio.repository.ClienteHasTransactionRepository;
import com.evertec.desafio.repository.LibroHasTransactionRepository;
import com.evertec.desafio.repository.TransactioRepository;

import jakarta.transaction.Transactional;

@Service
public class TransactionService {


    @Autowired
    private TransactioRepository transactioRepository;

    @Autowired
    private LibroHasTransactionRepository libroHasTransactionRepository;

    @Autowired
    private ClienteHasTransactionRepository clienteHasTransactionRepository;


    @Transactional
    public boolean saveTransaction(TransactionDTO transactionDto ) {

        try {

           

            Compra newCompra = new Compra();
            newCompra.setFecha(LocalDateTime.now());
            newCompra.setIdCompra(transactionDto.getIdTransaction());
            newCompra.setValorTotal(transactionDto.getValorTotal());

            Compra transaction =transactioRepository.save(newCompra);

            ClienteHasTransaction clienteTransaction = clienteHasTransactionRepository.save(new ClienteHasTransaction(transactionDto.getIdCliente(),transaction.getIdCompra()));
            

            clienteTransaction.getIdCliente();

            for (LibroHasTransaction libro : transactionDto.getListaLibro()) {

                libro.setIdCompra(transaction.getIdCompra());

                guardarLibroHasTransaction(libro);

            }

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

      
    }


    @Transactional
    public boolean guardarLibroHasTransaction(LibroHasTransaction libro) {

        try {

            libroHasTransactionRepository.save(libro);

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    public Object getAllTransaction() {

       List<TransactionDTO> listaTransaction = transactioRepository.getAlltransaction();

       return extracted(listaTransaction);

    }


     public Object getClienteTransaction(Integer idCompra, Integer idCliente) {

       List<TransactionDTO> listaTransaction = transactioRepository.getClientTransaction(idCompra, idCliente);

       return extracted(listaTransaction);
        
    }


    private List<TransactionDTO> extracted(List<TransactionDTO> listaTransaction) {

        for (TransactionDTO transaction : listaTransaction) {
            List<LibroHasTransaction> libros = libroHasTransactionRepository.getLibrosByIdCompra(transaction.getIdTransaction());
            transaction.setLista(libros);
            transaction.setCantidadLibro(libros.size());

           }
           return listaTransaction;
    }
    
    
}
