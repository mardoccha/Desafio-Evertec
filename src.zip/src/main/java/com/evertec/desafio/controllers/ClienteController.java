package com.evertec.desafio.controllers;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.evertec.desafio.dto.ErrorDetalles;
import com.evertec.desafio.entity.Cliente;
import com.evertec.desafio.service.ClienteService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;



@RestController
@RequestMapping("/api")
@Tag(name = "Clients")
@CrossOrigin(origins = "*") 
public class ClienteController {


    @Autowired
    ClienteService clienteService;
   
    @PostMapping("/guardar-cliente")
    @Operation(security = { @SecurityRequirement(name = "bearer-token") })
	public  ResponseEntity<Object>  saveCliente(@RequestBody Cliente cliente){

        Cliente newCliente = clienteService.addCliente(cliente);

        if (newCliente.equals(null)) {

            return new ResponseEntity<>(new ErrorDetalles(new Date(), "Error inesperado, vuelve a intetar!", cliente), HttpStatus.INTERNAL_SERVER_ERROR);
        }
         return new ResponseEntity<>(new ErrorDetalles(new Date(), "Cliente Creado!", newCliente), HttpStatus.OK);
	
    }


    @PostMapping("/listar-cliente")
    @Operation(security = { @SecurityRequirement(name = "bearer-token") })
	public  ResponseEntity<Object>  getAllCliente(){

      return   ResponseEntity.status(HttpStatus.OK)
                    .body(clienteService.getAllCliente());
    }

}
