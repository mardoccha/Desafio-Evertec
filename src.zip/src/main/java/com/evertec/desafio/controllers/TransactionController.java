package com.evertec.desafio.controllers;

import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.evertec.desafio.dto.ErrorDetalles;
import com.evertec.desafio.dto.TransactionDTO;
import com.evertec.desafio.entity.Cliente;
import com.evertec.desafio.entity.Libro;
import com.evertec.desafio.entity.LibroHasTransaction;
import com.evertec.desafio.service.ClienteService;
import com.evertec.desafio.service.LibroService;
import com.evertec.desafio.service.TransactionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;



@RestController
@RequestMapping("/api")
@Tag(name = "Transaction")
@CrossOrigin(origins = "*") 
public class TransactionController {


    @Autowired
    private TransactionService transactionService;

    @Autowired
    private LibroService libroService;
   
    private boolean hasErrors = false;
    private Integer valorTotal =0;


    @PostMapping("/guardar-transaction")
    @Operation(security = { @SecurityRequirement(name = "bearer-token") })
	public  ResponseEntity<Object>  saveTransaction(@RequestBody TransactionDTO transaction){

       

        transaction.getListaLibro().forEach(n -> 
        {
            Libro book = libroService.ifBookExist(n.getIdLibro());
            
            if (book==null){
                hasErrors = true;
                return;
            }else valorTotal += valorTotal+book.getValor()*n.getCantidad();
        });

        if (hasErrors) {
            return new ResponseEntity<>(new ErrorDetalles(new Date(), "El id de unos de los libros no existe, vuelve a intetar!", ""), HttpStatus.INTERNAL_SERVER_ERROR); 
        }

        transaction.setValorTotal(valorTotal);
        boolean respuesta = transactionService.saveTransaction(transaction);   

       
        if (!respuesta) {

            return new ResponseEntity<>(new ErrorDetalles(new Date(), "Error inesperado, vuelve a intetar!", ""), HttpStatus.INTERNAL_SERVER_ERROR);
        }
         return new ResponseEntity<>(new ErrorDetalles(new Date(), "Transaction Realizada!",""), HttpStatus.OK);
	
    }


    

    @GetMapping("/listar-transations")
    @Operation(security = { @SecurityRequirement(name = "bearer-token") })
	public  ResponseEntity<Object>  getAllTransaction(){

      return   ResponseEntity.status(HttpStatus.OK)
                    .body(transactionService.getAllTransaction());
    }


     @GetMapping("/listar-transation-cliente")
    @Operation(security = { @SecurityRequirement(name = "bearer-token") })
	public  ResponseEntity<Object>  getClienteTransaction(
        @RequestParam(required = true) Integer idCompra,
        @RequestParam(required = false) Integer idCliente
    ){


      return   ResponseEntity.status(HttpStatus.OK)
                    .body(transactionService.getClienteTransaction(idCompra, idCliente));
    }

}
